#pragma once

#ifndef EVENTFLAG_H
#define EVENTFLAG_H

#include "types.h"

int createEventFlag(const char *name);
int destroyEventFlag(int eventFlag);

#endif
