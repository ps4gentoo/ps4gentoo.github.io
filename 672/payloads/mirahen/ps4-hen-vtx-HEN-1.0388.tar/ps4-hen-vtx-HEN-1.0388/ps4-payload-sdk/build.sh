#!/bin/bash

# Build SDK
cd libPS4 || (echo "Unable to enter subdirectory" && exit)
make clean
make
cd ..


# Add to paths
echo "export PS4SDK=/home/mirco/ps4-payload-sdk"
export PS4SDK=/home/mirco/ps4-payload-sdk/libPS4
