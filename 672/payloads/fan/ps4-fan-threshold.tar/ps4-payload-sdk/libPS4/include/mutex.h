#pragma once

#ifndef MUTEX_H
#define MUTEX_H

#include "types.h"

#endif
